function myFunction() {
        document.getElementById("show_after").style.display = "block";
}
function myFunction1() {
        document.getElementById("show_after1").style.display = "block";
}
function myFunction2() {
        document.getElementById("show_after2").style.display = "block";
}